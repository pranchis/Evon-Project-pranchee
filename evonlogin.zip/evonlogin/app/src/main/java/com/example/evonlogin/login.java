package com.example.evonlogin;

import androidx.appcompat.app.AppCompatActivity;


import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class login extends AppCompatActivity {
    private static final String MESSAGE_KEY = "Login.senddata.message_key";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        View e2 = (EditText) findViewById(R.id.e2);
        View p2 = (EditText) findViewById(R.id.p2);
        View b1 = findViewById(R.id.login2);


        b1.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                if (((EditText)e2).getText().toString().equals("admin") &&
                        ((EditText) p2).getText().toString().equals("admin")) {
                    Toast.makeText(getApplicationContext(), "Redirecting...", Toast.LENGTH_SHORT).show();
                    Intent intent= new Intent(getApplicationContext(),Homepage.class);
                    startActivity(intent);
                    sendmessage();
                }
                else
                {
                    Toast.makeText(getApplicationContext(), "Wrong Credentials", Toast.LENGTH_SHORT).show();
                }
            };
            public void sendmessage() {
                String message1 = ((EditText) e2).getText().toString();
                String message2 = ((EditText) p2).getText().toString();
                Intent intent= new Intent(getApplicationContext(),Homepage.class);
                intent.putExtra(MESSAGE_KEY,message1);
                intent.putExtra(MESSAGE_KEY,message2);
                startActivity(intent);
            }
        });
    }
}
