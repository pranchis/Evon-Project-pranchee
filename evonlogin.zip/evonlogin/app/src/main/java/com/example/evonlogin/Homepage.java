package com.example.evonlogin;


import androidx.appcompat.app.AppCompatActivity;

        import android.content.Intent;
        import android.os.Bundle;
        import android.view.View;
        import android.widget.EditText;
        import android.widget.TextView;

        import java.text.BreakIterator;

public class Homepage extends AppCompatActivity {

    private static final String MESSAGE_KEY = "Login.senddata.message_key";
//    View ed1 = (TextView) findViewById(R.id.username);
//    View ed2 = (TextView) findViewById(R.id.editTextTextPassword);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

                setContentView(R.layout.activity_homepage);



        Intent intent = getIntent();
        String message1 = intent.getStringExtra(MESSAGE_KEY);
        String message2 = intent.getStringExtra(MESSAGE_KEY);

        TextView ed1 = (TextView) findViewById(R.id.username);
        TextView ed2 = (TextView) findViewById(R.id.editTextTextPassword);
        ed1.setText(message1);
        ed2.setText(message2);






    }
}